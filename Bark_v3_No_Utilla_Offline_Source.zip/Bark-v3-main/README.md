# Revive of Bark (aka Grate) (fork this im not maintaining)

### Imaginary Rules

- No modifications that make Bark a cheat
- Do not abuse glitches.
- Refrain from trolling or deciving other gorillas.
- Have fun.

### Credits

- Graze is the previous maintainer of Bark
- KyleTheScientist made the backbone of Bark called Bark.
- baggZ, Gadabuda, Monky made mods



This product is not affiliated with Another Axiom Inc. or its videogames Gorilla Tag and Orion Drift and is not endorsed or otherwise sponsored by Another Axiom. Portions of the materials contained herein are property of Another Axiom. ©2021 Another Axiom Inc.
