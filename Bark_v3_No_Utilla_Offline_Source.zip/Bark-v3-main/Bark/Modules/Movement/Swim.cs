﻿using Bark.GUI;
using GorillaLocomotion;
using UnityEngine;

namespace Bark.Modules;

public class Swim : BarkModule
{
    public static readonly string DisplayName = "Swim";
    public GameObject? waterVolume;

    protected override void Start()
    {
        base.Start();
        var source = GameObject.Find("Environment Objects/LocalObjects_Prefab/ForestToBeach/ForestToBeach_Prefab_V4/CaveWaterVolume");
        if (source == null)
        {
            // Try alternative path for newer game versions
            source = GameObject.Find("CaveWaterVolume");
        }
        if (source == null || VRRig.LocalRig == null)
        {
            Bark.Tools.Logging.Warning("Swim: Could not find CaveWaterVolume or LocalRig");
            return;
        }
        waterVolume = Instantiate(source, VRRig.LocalRig.transform);
        waterVolume.transform.localScale = new Vector3(5f, 1000f, 5f);
        waterVolume.transform.localPosition = new Vector3(0, 50, 0);
        waterVolume.SetActive(false);
        if (waterVolume.GetComponent<Renderer>()) waterVolume.GetComponent<Renderer>().enabled = false;
        if (waterVolume.GetComponentInChildren<Renderer>())
            waterVolume.GetComponentInChildren<Renderer>().enabled = false;
    }

    private void LateUpdate()
    {
        GTPlayer.Instance.audioManager.UnsetMixerSnapshot();
    }

    protected override void OnEnable()
    {
        if (!MenuController.Instance.Built) return;
        base.OnEnable();
        waterVolume?.SetActive(true);
    }

    protected override void Cleanup()
    {
        if (!MenuController.Instance.Built) return;
        waterVolume?.SetActive(false);
        GTPlayer.Instance.audioManager.UnsetMixerSnapshot();
    }

    public override string GetDisplayName()
    {
        return DisplayName;
    }

    public override string Tutorial()
    {
        return "Effect: Surrounds you with invisible water.";
    }
}