﻿using System;
using Bark.GUI;
using Bark.Networking;
using Bark.Patches;
using Bark.Tools;
using Bark.Extensions;
using UnityEngine;
using NetworkPlayer = NetPlayer;

namespace Bark.Modules.Misc;

public class HaloMarker : MonoBehaviour
{
    private readonly Quaternion rotation = Quaternion.Euler(180, 0, 0);
    private GameObject halo, lightBeam;

    private void Start()
    {
        try
        {
            halo = Instantiate(Halo.haloPrefab);
            lightBeam = Instantiate(Halo.lightBeamPrefab);
            var rig = GetComponent<VRRig>();
            halo.transform.SetParent(rig.headMesh.transform, false);
            halo.transform.localPosition = new Vector3(0, .15f, 0);
            halo.transform.localRotation = Quaternion.Euler(69, 0, 0);
            lightBeam.transform.SetParent(rig.transform, false);
        }
        catch (Exception e)
        {
            Logging.Exception(e);
        }
    }

    private void FixedUpdate()
    {
        lightBeam.transform.rotation = rotation;
    }

    private void OnDestroy()
    {
        Destroy(halo);
        Destroy(lightBeam);
    }
}

public class Halo : BarkModule
{
    public static readonly string DisplayName = "Halo";
    public static GameObject haloPrefab, lightBeamPrefab;
    private HaloMarker myMarker;

    private void Awake()
    {
        if (!haloPrefab)
        {
            haloPrefab = Plugin.AssetBundle.LoadAsset<GameObject>("Halo");
            lightBeamPrefab = Plugin.AssetBundle.LoadAsset<GameObject>("Light Beam");
        }

        VRRigCachePatches.OnRigCached += OnRigCached;
    }

    protected override void OnEnable()
    {
        if (!MenuController.Instance.Built) return;
        base.OnEnable();

        try
        {
            myMarker = GorillaTagger.Instance.offlineVRRig.gameObject.AddComponent<HaloMarker>();
        }
        catch (Exception e)
        {
            Logging.Exception(e);
        }
    }

    private void OnRigCached(NetPlayer player, VRRig rig)
    {
        rig?.gameObject?.GetComponent<HaloMarker>()?.Obliterate();
    }

    protected override void Cleanup()
    {
        //foreach (var marker in FindObjectsOfType<HaloMarker>())
        Destroy(myMarker);
    }

    public override string GetDisplayName()
    {
        return DisplayName;
    }

    public override string Tutorial()
    {
        return "Proof of Kyle";
    }
}