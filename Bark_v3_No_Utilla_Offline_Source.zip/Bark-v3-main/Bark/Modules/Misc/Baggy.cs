﻿using System;
using Bark.Gestures;
using Bark.GUI;
using Bark.Networking;
using Bark.Patches;
using Bark.Tools;
using Bark.Extensions;
using UnityEngine;
using NetworkPlayer = NetPlayer;

namespace Bark.Modules.Misc;

public class Baggy : BarkModule
{
    public static string DisplayName = "Bag";
    private static GameObject? Bag;

    protected override void Start()
    {
        base.Start();
        if (Bag == null)
        {
            Bag = Instantiate(Plugin.AssetBundle.LoadAsset<GameObject>("Bag"));
            Bag.transform.SetParent(GestureTracker.Instance.rightHand.transform, true);
            Bag.transform.localRotation = Quaternion.Euler(9, 0, 0);
            Bag.transform.localScale /= 4;
            Bag.SetActive(false);
        }
        
        VRRigCachePatches.OnRigCached += OnRigCached;
    }

    protected override void OnEnable()
    {
        if (!MenuController.Instance.Built) return;
        base.OnEnable();
        try
        {
            GestureTracker.Instance.rightGrip.OnPressed += ToggleBagOn;
            GestureTracker.Instance.rightGrip.OnReleased += ToggleBagOff;
        }
        catch (Exception e)
        {
            Logging.Exception(e);
        }
    }


    private void ToggleBagOn(InputTracker tracker)
    {
        Bag?.SetActive(true);
    }

    private void ToggleBagOff(InputTracker tracker)
    {
        Bag?.SetActive(false);
    }

    protected override void Cleanup()
    {
        Bag?.SetActive(false);
        if (GestureTracker.Instance != null)
        {
            GestureTracker.Instance.rightGrip.OnPressed -= ToggleBagOn;
            GestureTracker.Instance.rightGrip.OnReleased -= ToggleBagOff;
        }
    }

    private void OnRigCached(NetPlayer player, VRRig rig)
    {
        rig?.gameObject?.GetComponent<NetBag>()?.Obliterate();
    }

    public override string GetDisplayName()
    {
        return DisplayName;
    }

    public override string Tutorial()
    {
        return "baggZ";
    }

    private class NetBag : MonoBehaviour
    {
        private NetworkedPlayer networkedPlayer;
        private GameObject Bag;

        private void OnEnable()
        {
            networkedPlayer = gameObject.GetComponent<NetworkedPlayer>();
            var rightHand = networkedPlayer.rig.rightHandTransform;

            Bag = Instantiate<GameObject>(Baggy.Bag);

            Bag.transform.SetParent(rightHand);
            Bag.transform.localPosition = new Vector3(0.04f, 0.05f, -0.02f);
            Bag.transform.localRotation = Quaternion.Euler(270, 163.12f, 0);
            Bag.transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);

            networkedPlayer.OnGripPressed += OnGripPressed;
            networkedPlayer.OnGripReleased += OnGripReleased;
        }

        private void OnDisable()
        {
            Bag.Obliterate();
            networkedPlayer.OnGripPressed -= OnGripPressed;
            networkedPlayer.OnGripReleased -= OnGripReleased;
        }

        private void OnDestroy()
        {
            Bag.Obliterate();
            networkedPlayer.OnGripPressed -= OnGripPressed;
            networkedPlayer.OnGripReleased -= OnGripReleased;
        }

        private void OnGripPressed(NetworkedPlayer player, bool isLeft)
        {
            if (!isLeft) Bag.SetActive(true);
        }

        private void OnGripReleased(NetworkedPlayer player, bool isLeft)
        {
            if (!isLeft) Bag.SetActive(false);
        }
    }
}