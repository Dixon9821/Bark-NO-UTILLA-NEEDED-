using HarmonyLib;
using UnityEngine;

namespace Bark.Patches;

[HarmonyPatch(typeof(GameObject))]
[HarmonyPatch(nameof(GameObject.CreatePrimitive), MethodType.Normal)]
internal class GameObjectPatch
{
    private static void Postfix(GameObject __result)
    {
        __result.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
        __result.GetComponent<Renderer>().material.color = Color.white;
    }
}