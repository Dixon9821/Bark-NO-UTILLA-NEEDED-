Bark v3 - Utilla-free offline-only source variant

Changes:
- Removed Utilla assembly reference and plugin dependency/attributes.
- Initialize Bark when game has initialized and Photon is not in a room.
- Deactivate Bark upon entering any multiplayer room.
- Guard NetworkPropertyHandler from accessing Photon room data while offline.

This is NOT a ban bypass. Server bans and server-side permissions are unaffected.
This source has NOT been compiled or tested against your Gorilla Tag assemblies.

Build from Bark-v3-main/Bark using: dotnet build -c Release
Install resulting Bark.dll in BepInEx/plugins only after backing up existing DLL.
If build fails, share the compiler output. If runtime fails, share BepInEx/LogOutput.log.
